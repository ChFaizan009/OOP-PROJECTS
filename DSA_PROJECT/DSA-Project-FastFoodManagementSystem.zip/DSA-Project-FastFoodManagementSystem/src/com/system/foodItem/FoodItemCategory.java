package com.system.foodItem;

public enum FoodItemCategory {
	FastFood("FastFood"),
	Dessert("Dessert"),
	Drink("Drink");

	FoodItemCategory(String string) {}
}
