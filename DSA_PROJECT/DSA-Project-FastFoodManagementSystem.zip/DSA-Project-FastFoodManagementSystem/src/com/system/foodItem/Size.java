package com.system.foodItem;

public enum Size{
	SMALL("Small"),
	MEDIUM("Medium"),
	REGULAR("Regular"),
	LARGE("Large"),
	X_LARGE("X-Large");
	Size(String string) {}
}
