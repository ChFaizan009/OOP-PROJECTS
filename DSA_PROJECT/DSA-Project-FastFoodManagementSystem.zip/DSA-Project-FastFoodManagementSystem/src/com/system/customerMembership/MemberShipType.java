package com.system.customerMembership;

public enum MemberShipType{
	BRONZE("Bronze"),
	SILVER("Silver"),
	GOLD("Gold");

	MemberShipType(String string) {}
}
