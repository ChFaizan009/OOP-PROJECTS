package com.system.employee;

public enum EmployeeStatus {
	
	Single("Single"),
	Married("Married"),
	Student("Student");

	EmployeeStatus(String string) {}
}
