SELECT * FROM fastfood.employee;
SELECT * FROM fastfood.customer_member_ship;
SELECT * FROM fastfood.fooditem;
SELECT * FROM fastfood.customer;
SELECT * FROM fastfood.orders;
select * FROM fastfood.adminsecurity;
SET SQL_SAFE_UPDATES = 0;

